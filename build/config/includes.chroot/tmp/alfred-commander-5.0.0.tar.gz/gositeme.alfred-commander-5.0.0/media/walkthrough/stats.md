# Account & Usage

Monitor your plan, usage, and billing from inside the IDE.

## How to Access
Click your **username** in the bottom status bar, or run:
- Command Palette → "Alfred: Account & Usage Stats"

## What You'll See
- **Plan**: Your current subscription tier
- **Token Usage**: How many AI tokens you've consumed
- **Credit Balance**: Remaining credits for the billing period
- **Active Services**: Which ecosystem services are linked

## Commander Access
If you're the Commander (client_id 33), you have unlimited access — no token limits, no restrictions.
