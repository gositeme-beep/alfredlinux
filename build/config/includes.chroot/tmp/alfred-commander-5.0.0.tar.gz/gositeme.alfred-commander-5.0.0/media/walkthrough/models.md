# AI Models

Alfred IDE supports multiple AI providers and models.

## Available Tiers

| Tier | Best For | Examples |
|------|----------|---------|
| **Leaf** | Simple tasks, quick answers | GPT-4o-mini, local Ollama |
| **Mid** | Code generation, analysis | Claude 3.5 Sonnet, GPT-4o |
| **Frontier** | Complex reasoning, architecture | Claude Opus, GPT-4 |
| **Max** | Research, multi-step planning | Claude Opus (extended) |

## How to Switch
Use the **model dropdown** at the top of the Alfred panel to select your preferred model.

## Local Models
If Ollama is running, local models appear automatically — your code never leaves your machine.
