# Voice Commands

Talk to your IDE — Alfred listens, transcribes, and responds.

## How It Works
1. Click the **🎤 microphone** button in the Alfred panel
2. Speak naturally — your voice is transcribed in real time
3. Alfred processes your request and responds

## Voice Architecture
- **STT (Speech-to-Text)**: Whisper-based transcription
- **LLM**: Your selected AI model processes the request
- **TTS (Text-to-Speech)**: Kokoro voices read the response back

## Tips
- Speak clearly and at a normal pace
- You can say "stop" or click the mic again to end recording
- Voice works best with short, focused requests
