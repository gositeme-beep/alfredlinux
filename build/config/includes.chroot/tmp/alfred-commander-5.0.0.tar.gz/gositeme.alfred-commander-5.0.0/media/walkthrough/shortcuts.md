# Keyboard Shortcuts

Master these to work at full speed.

## Alfred Commands
| Shortcut | Action |
|----------|--------|
| `Ctrl+Shift+Alt+O` | Open Alfred Panel |
| `Ctrl+Shift+Alt+A` | Toggle Voice Mode |

## Essential IDE Shortcuts
| Shortcut | Action |
|----------|--------|
| `Ctrl+P` | Quick File Open |
| `Ctrl+Shift+P` | Command Palette |
| `Ctrl+`` ` | Toggle Terminal |
| `Ctrl+B` | Toggle Sidebar |
| `Ctrl+Shift+E` | File Explorer |
| `Ctrl+Shift+F` | Search Across Files |
| `Ctrl+Shift+G` | Source Control |
| `F5` | Start Debugging |
| `Ctrl+/` | Toggle Line Comment |
| `Alt+↑/↓` | Move Line Up/Down |
| `Ctrl+D` | Select Next Occurrence |
