# Meet Alfred

Alfred is your AI coding companion, built into the sidebar.

## What Alfred Can Do
- **Answer questions** about your code, frameworks, and tools
- **Generate code** from natural language descriptions
- **Debug issues** by analyzing errors and suggesting fixes
- **Explain code** — select any block and ask "what does this do?"
- **Run tools** — file search, terminal commands, web lookups

## How to Start
1. Click the **Alfred icon** (🅰️) in the activity bar (left side)
2. Type your question or request in the chat input
3. Press Enter — Alfred responds in real time

Alfred remembers your conversation context, so you can have natural multi-turn discussions about your code.
